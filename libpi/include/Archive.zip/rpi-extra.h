#ifndef __RPI_EXTRA_H__
#define __RPI_EXTRA_H__

// put all your new prototypes in here: we will not modify.

#endif
